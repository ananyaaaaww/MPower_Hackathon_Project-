# FC36-THEITGUY
# MPower 
Invest in Mindset

![cf041e54-c72d-4127-a9cc-aecfe3c397b9](https://user-images.githubusercontent.com/84352394/173156471-634a4e27-3c56-4b31-9dd6-aa0217510226.jpg)

We aim at empowering mind's power.In a country like India where even talking about MH issues is a taboo, our goal is to be a part of change and work on spreading awarness and normalise talking about these issues.MH is just as important as physical and our website solely focuses on the users mental health.
'Two out of three people suffer in silence,we are here to change that.'



## FEATURES

[![Self Help A guide ](https://img.shields.io/badge/Self%20Care-A%20guide%20to%20your%20MH-blue)](https://github.com/tterb/atomic-design-ui/blob/master/LICENSEs)
       
        Most Indians are unaware of how they feel and how to cope up with those.
        So we have come up with a Section who's sole focus is to educate and 
        spread awarness about the common MH issues. 
                1.Medication related to the same 
                2.Simple and handy tips  to overcome them
                3.Questions to journal and think about
                4.How to deal with somone who's going through them
                5.Videos regarding the same for better understanding
                6.Videos and links that make you feel better.  



[![GPLv3 License](https://img.shields.io/badge/Remote%20Consultation-Virtual%20Consultation%20with%20Qualified%20doctors-yellowgreen)](https://opensource.org/licenses/)

        Professional help might not always be accessible for people.It often comes with 
        social stigma or "what will people say". We focus on providing these services virtually.
        This makes it easier for people to recieve required professional help and choose 
        from a wide range of doctors specialising in various fields.Few of the features here:
                1.Doctors profiles with their descriptions
                2.Customer review based rating 
                3.Feedback forms
                4.Online consultations as per convenience

[![AGPL License](https://img.shields.io/badge/Emotional%20Support-Corner%20to%20open%20up%20about%20your%20issues%20anonymously-orange)](http://www.gnu.org/licenses/agpl-3.0)

     Opening up to people about how you feel might be tougher than most people anticipate
     So we have implemented a system where user can open up to us anonymously and post their 
     issues.Our goal is to encourage users to realise that MH issues are common and not a 
     topic to avoid.
               1.Guidelines related to sexual harrasment and domestic abuse to empower victims to speak up.
               2.Solutions to ususal MH issues faced by people of varying age groups
               3.Words of affirmations.

[![AGPL License](https://img.shields.io/badge/Survey-Know%20more%20about%20your%20MH-red)](http://www.gnu.org/licenses/agpl-3.0)

     Most people aren't aware of how they feel and most symptoms go unnoticed.We have curated
     a survey which helps us analyse the mental health of our users.Once the survey is filled
     we get back to the users with their results and recomendations
            1.Easy to fill survey 
            2.Understandable language 
            3.Urges users to think about the state of their MH 
            
[![AGPL License](https://img.shields.io/badge/Donation-Donate%20to%20improve%20the%20community%20health%20-blueviolet)](http://www.gnu.org/licenses/agpl-3.0)
  
          MH care is majorly inaccessible due to financial constrains for most people.
          To make it more affordable we have introduced Dontation option wherein intered individuals
          can donate to be a part of the change.These funds can be requested by contacting us.


[![AGPL License](https://img.shields.io/badge/FAQ-Know%20more%20about%20general%20MH%20Care-yellow)](http://www.gnu.org/licenses/agpl-3.0)
      
       Understanding the significance of MH is the first step to a healthier mind.We have a FAQ page 
       the most frequently asked questions regarding mental healthcare.We believe that awarness is the 
       first step to a healtheir mind set.Education and empowerment is our primary goal.
      
[![AGPL License](https://img.shields.io/badge/Contact%20us-Get%20in%20touch%20with%20us%20-9cf)](http://www.gnu.org/licenses/agpl-3.0)

        Contact us for any queries or suggestions.
        
## Documentation
This project was developed in under 24 hours with help of
     
          HTML
          CSS
          Javascript
          Bootstrap
          Tidio
   
            We used Tidio to develop the chatbox and Javascript for the backend functionality.
            CSS and HTML were used to develop most of our features.


## Developers
Kareena Gauri

Ananya C

Ananya N

Varshitha K

## Demo

The following are the screenshots of our website.

Our Homescreen:


![1](https://user-images.githubusercontent.com/105562540/173172168-eebc4e05-d45c-435e-8c19-b7c1b0db0b21.png)



Chatbot:
![1](https://user-images.githubusercontent.com/75038092/173176505-31b81a50-21d3-4119-9e85-55624af81eb7.png)


Our Services:

![3](https://user-images.githubusercontent.com/105562540/173172220-46ad061a-8b1a-4bf0-90bd-3428b1263545.png)

Self Help page:


![4](https://user-images.githubusercontent.com/105562540/173172225-5f0e3d8b-0d1b-49b4-a5fb-9156b3ac0fd9.png)


Contact us 


![5](https://user-images.githubusercontent.com/105562540/173172226-64c90081-bdac-4321-bb8a-26b160292dc5.png)


## OUR ROUND 1 FANTOM CODE'22 PRESENTATION : 

A screenshot from the presentataion


![6](https://user-images.githubusercontent.com/105562540/173172235-b587ee9a-1354-439a-851d-0ee5bf28e80d.png)


Our presentation link:

https://www.canva.com/design/DAE14d2A35I/8jeKvR6fciOrYEQfAKVy-w/view?utm_content=DAE14d2A35I&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton 

